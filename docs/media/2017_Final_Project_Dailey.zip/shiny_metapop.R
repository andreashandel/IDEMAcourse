############################################################
#This is the Shiny file for the Metapopulation App
#written by Andreas Handel and Cody Dailey, with contributions from others 
#maintained by Andreas Handel (ahandel@uga.edu)
#last updated 11/27/2017
############################################################

#the server-side function with the main functionality
#this function is wrapped inside the shiny server function below to allow return to main menu when window is closed
refresh <- function(input, output){
  
  # This reactive takes the input data and sends it over to the simulator
  # Then it will get the results back and return it as the "res" variable
  res <- reactive({
    input$submitBtn
    
    # Read all the input values from the UI
    Sh0.A = isolate(input$Sh0.A);
    Eh0.A = isolate(input$Eh0.A)
    Ih0.A = isolate(input$Ih0.A);
    Rh0.A = isolate(input$Rh0.A)
    Sv0.A = isolate(input$Sv0.A);
    Ev0.A = isolate(input$Ev0.A)
    Iv0.A = isolate(input$Iv0.A);
    b1.A   = isolate(input$b1.A);
    b2.A   = isolate(input$b2.A);
    bir.A  = isolate(input$bir.A);
    dea.A  = isolate(input$dea.A);
    g.A    = isolate(input$g.A);
    w.A    = isolate(input$w.A);
    
    Sh0.B = isolate(input$Sh0.B);
    Eh0.B = isolate(input$Eh0.B)
    Ih0.B = isolate(input$Ih0.B);
    Rh0.B = isolate(input$Rh0.B)
    Sv0.B = isolate(input$Sv0.B);
    Ev0.B = isolate(input$Ev0.B)
    Iv0.B = isolate(input$Iv0.B);
    b1.B   = isolate(input$b1.B);
    b2.B   = isolate(input$b2.B);
    bir.B  = isolate(input$bir.B);
    dea.B  = isolate(input$dea.B);
    g.B    = isolate(input$g.B);
    w.B    = isolate(input$w.B);
    
    Sh0.C = isolate(input$Sh0.C);
    Eh0.C = isolate(input$Eh0.C)
    Ih0.C = isolate(input$Ih0.C);
    Rh0.C = isolate(input$Rh0.C)
    Sv0.C = isolate(input$Sv0.C);
    Ev0.C = isolate(input$Ev0.C)
    Iv0.C = isolate(input$Iv0.C);
    b1.C   = isolate(input$b1.C);
    b2.C   = isolate(input$b2.C);
    bir.C  = isolate(input$bir.C);
    dea.C  = isolate(input$dea.C);
    g.C    = isolate(input$g.C);
    w.C    = isolate(input$w.C);
    
    
    
    
    tmax = isolate(input$tmax);
    incu = isolate(input$incu)
    ma   = isolate(input$ma)
    
    m.AA = isolate(input$m.AA)
    m.BB = isolate(input$m.BB)
    m.CC = isolate(input$m.CC)
    
    m.AB = isolate(input$m.AB)
    m.AC = isolate(input$m.AC)
    
    m.BA = isolate(input$m.BA)
    m.BC = isolate(input$m.BC)
    
    m.CA = isolate(input$m.CA)
    m.CB = isolate(input$m.CB)
    
    
    # Call the ODE solver with the given parameters
    result <- simulate_metapopulation(Sh0.A = Sh0.A, Eh0.A = Eh0.A, Ih0.A = Ih0.A, Rh0.A = Rh0.A, Sv0.A = Sv0.A, Ev0.A = Ev0.A, Iv0.A = Iv0.A, 
                                      Sh0.B = Sh0.B, Eh0.B = Eh0.B, Ih0.B = Ih0.B, Rh0.B = Rh0.B, Sv0.B = Sv0.B, Ev0.B = Ev0.B, Iv0.B = Iv0.B,
                                      Sh0.C = Sh0.C, Eh0.C = Eh0.C, Ih0.C = Ih0.C, Rh0.C = Rh0.C, Sv0.C = Sv0.C, Ev0.C = Ev0.C, Iv0.C = Iv0.C,
                                      
                                      b1.A = b1.A, b2.A = b2.A, bir.A = bir.A, dea.A = dea.A, g.A = g.A, w.A = w.A,
                                      b1.B = b1.B, b2.B = b2.B, bir.B = bir.B, dea.B = dea.B, g.B = g.B, w.B = w.B,
                                      b1.C = b1.C, b2.C = b2.C, bir.C = bir.C, dea.C = dea.C, g.C = g.C, w.C = w.C,
                                      
                                      tmax = tmax, incu = incu, ma = ma, 
                                      
                                      m.AA = m.AA, m.BB = m.BB, m.CC = m.CC,
                                      m.AB = m.AB, m.AC = m.AC, 
                                      m.BA = m.BA, m.BC = m.BC,
                                      m.CA = m.CA, m.CB = m.CB)
    
    return(list(result)) #this is returned as the res variable
  })
  
  #if we want certain variables plotted and reported separately, we can specify them manually as a list
  #if nothing is specified, all variables are plotted and reported at once
  varlist = list(c("Sh.A", "Eh.A", "Ih.A", "Rh.A"), c("Sh.B", "Eh.B", "Ih.B", "Rh.B"), c("Sh.C","Eh.C", "Ih.C","Rh.C"), c("Sv.A","Ev.A","Iv.A"),  c("Sv.B","Ev.B","Iv.B"),  c("Sv.C","Ev.C","Iv.C"))
  #function that takes result saved in res and produces output
  #output (plots, text, warnings) is stored in and modifies the global variable 'output'
  generate_simoutput(input,output,res,varlist=varlist)
} #ends the 'refresh' shiny server function that runs the simulation and returns output

#main shiny server function
server <- function(input, output, session) {
  
  # Waits for the Exit Button to be pressed to stop the app and return to main menu
  observeEvent(input$exitBtn, {
    input$exitBtn
    stopApp(returnValue = 0)
  })
  
  # This function is called to refresh the content of the Shiny App
  refresh(input, output)
  
  # Event handler to listen for the webpage and see when it closes.
  # Right after the window is closed, it will stop the app server and the main menu will
  # continue asking for inputs.
  session$onSessionEnded(function(){
    stopApp(returnValue = 0)
  })
} #ends the main shiny server function


#This is the UI part of the shiny App
ui <- fluidPage(
  includeCSS("../styles/dsaide.css"),
  #add header and title
  
  div( includeHTML("www/header.html"), align = "center"),
  #specify name of App below, will show up in title
  h1('Metapopulation App', align = "center", style = "background-color:#123c66; color:#fff"),
  
  #section to add buttons
  fluidRow(
    column(6,
           actionButton("submitBtn", "Run Simulation", class="submitbutton")  
    ),
    column(6,
           actionButton("exitBtn", "Exit App", class="exitbutton")
    ),
    align = "center"
  ), #end section to add buttons
  
  tags$hr(),
  
  ################################
  #Split screen with input on left, output on right
  fluidRow(
    #all the inputs in here
    column(6,
           #################################
           # Inputs section
           h2('Simulation Settings'),
           fluidRow(
             column(4,
                    numericInput("Sh0.A", "initial number of susceptible hosts in pop A (Sh0.A)", min = 1000, max = 5000, value = 1000, step = 500)
             ),
             column(4,
                    numericInput("Sv0.A", "initial number of susceptible vectors in pop A (Sv0.A)", min = 1000, max = 5000, value = 1000, step = 500)
             ),
             column(4,
                    numericInput("Ih0.A", "initial number of infected hosts in pop A (Ih0.A)", min = 0, max = 100, value = 0, step = 1)
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("Sh0.B", "initial number of susceptible hosts in pop B (Sh0.B)", min = 1000, max = 5000, value = 1000, step = 500)
             ),
             column(4,
                    numericInput("Sv0.B", "initial number of susceptible vectors in pop B (Sv0.B)", min = 1000, max = 5000, value = 1000, step = 500)
             ),
             column(4,
                    numericInput("Ih0.B", "initial number of infected hosts in pop B (Ih0.B)", min = 0, max = 100, value = 0, step = 1)
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("Sh0.C", "initial number of susceptible hosts in pop C (Sh0.C)", min = 1000, max = 5000, value = 1000, step = 500)
             ),
             column(4,
                    numericInput("Sv0.C", "initial number of susceptible vectors in pop C (Sv0.C)", min = 1000, max = 5000, value = 1000, step = 500)
             ),
             column(4,
                    numericInput("Ih0.C", "initial number of infected hosts in pop C (Ih0.C)", min = 0, max = 100, value = 0, step = 1)
             ),
             align = "center"
           ), #close fluidRow structure for input
           
           fluidRow(
             column(4,
                    numericInput("Iv0.A", "initial number of infected vectors in pop A (Iv0.A)", min = 0, max = 100, value = 0, step = 1)
             ),
             column(4,
                    numericInput("Iv0.B", "initial number of infected vectors in pop B (Iv0.B)", min = 0, max = 100, value = 0, step = 1)
             ),
             column(4,
                    numericInput("Iv0.C", "initial number of infected vectors in pop C (Iv0.C)", min = 0, max = 100, value = 0, step = 1)
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("tmax", "Maximum simulation time (tmax)", min = 1, max = 500, value = 100, step = 1)
             ),
             column(4,
                    numericInput("w.A", "Rate of waning immunity in pop A (w.A)", min = 0, max = 1, value = 0, step = 0.01 )
             ),
             column(4,
                    numericInput("w.B", "Rate of waning immunity in pop B (w.B)", min = 0, max = 1, value = 0, step = 0.01 )
             ),
             column(4,
                    numericInput("w.C", "Rate of waning immunity in pop C (w.C)", min = 0, max = 1, value = 0, step = 0.01 )
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("b1.A", "vector to host transmission rate in A (b1.A)", min = 0, max = 0.01, value = 0, step = 0.0001  )
             ),
             column(4,
                    numericInput("b1.B", "vector to host transmission rate in B (b1.B)", min = 0, max = 0.01, value = 0, step = 0.0001  )
             ),
             column(4,
                    numericInput("b1.C", "vector to host transmission rate in C (b1.C)", min = 0, max = 0.01, value = 0, step = 0.0001  )
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("b2.A", "host to vector transmission rate in A (b2.A)", min = 0, max = 0.01, value = 0, step = 0.0001  )
             ),
             column(4,
                    numericInput("b2.B", "host to vector transmission rate in B (b2.B)", min = 0, max = 0.01, value = 0, step = 0.0001  )
             ),
             column(4,
                    numericInput("b2.C", "host to vector transmission rate in C (b2.C)", min = 0, max = 0.01, value = 0, step = 0.0001  )
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("g.A", "Rate of recovery of infected hosts in A (g.A)", min = 0, max = 10, value = 1, step = 0.1)
             ),
             column(4,
                    numericInput("g.B", "Rate of recovery of infected hosts in B (g.B)", min = 0, max = 10, value = 1, step = 0.1)
             ),
             column(4,
                    numericInput("g.C", "Rate of recovery of infected hosts in C (g.C)", min = 0, max = 10, value = 1, step = 0.1)
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("bir.A", "Rate of new vector births in A (bir.A)", min = 0, max = 10000, value = 0, step = 100)
             ),
             column(4,
                    numericInput("bir.B", "Rate of new vector births in B (bir.B)", min = 0, max = 10000, value = 0, step = 100)
             ),
             column(4,
                    numericInput("bir.C", "Rate of new vector births in C (bir.C)", min = 0, max = 10000, value = 0, step = 100)
             ),
             
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(4,
                    numericInput("dea.A", "Vector death rate in A (dea.A)", min = 0, max = 2, value = 0, step = 0.01 )
             ),
             column(4,
                    numericInput("dea.B", "Vector death rate in B (dea.B)", min = 0, max = 2, value = 0, step = 0.01 )
             ),
             column(4,
                    numericInput("dea.C", "Vector death rate in C (dea.C)", min = 0, max = 2, value = 0, step = 0.01 )
             ),
             align = "center"
           ), #close fluidRow structure for input
           fluidRow(
             column(6,
                    numericInput("incu", "Intrinsic latency (incu)", min = 0, max = 1, value = 0, step = 0.01)
             ),
             column(6,
                    numericInput("ma", "Extrinsic latency (ma)", min = 0, max = 1, value = 0, step = 0.01)
             ),
             align = "center"
           ) #close fluidRow structure for input
    ), #end sidebar column for inputs
    
    #all the outcomes here
    column(6,
           
           #################################
           #Start with results on top
           h2('Simulation Results'),
           plotOutput(outputId = "plot", height = "500px"),
           # PLaceholder for results of type text
           htmlOutput(outputId = "text"),
           #Placeholder for any possible warning or error messages (this will be shown in red)
           htmlOutput(outputId = "warn"),
           
           tags$head(tags$style("#warn{color: red;
                                font-style: italic;
                                }")),
           tags$hr()
           
           ) #end main panel column with outcomes
  ), #end layout with side and main panel
  
  #################################
  #Instructions section at bottom as tabs
  h2('Instructions'),
  #use external function to generate all tabs with instruction content
  do.call(tabsetPanel,generate_instruction_tabs()),
  div(includeHTML("www/footer.html"), align="center", style="font-size:small") #footer
  
  ) #end fluidpage function, i.e. the UI part of the app

shinyApp(ui = ui, server = server)