METAPOP.eq <- function(t, y, parms)
{
  with(
    as.list(c(y,parms)),
    {
      #the ordinary differential equations
      
      dSh.A = -Sh.A*b1.A*Iv.A+m.AA*w.A*Rh.A-(m.AB+m.AC)*Sh.A+m.BA*Sh.B+m.CA*Sh.C+m.BA*w.B*Rh.B+m.CA*w.C*Rh.C
      dEh.A = m.AA*Sh.A*b1.A*Iv.A-incu*Eh.A+m.BA*Sh.B*b1.B*Iv.B+m.CA*Sh.C*b1.C*Iv.C+m.BA*Eh.B+m.CA*Eh.C-(m.AB+m.AC)*Eh.A
      dIh.A = m.AA*incu*Eh.A-g.A*Ih.A+m.BA*incu*Eh.B+m.CA*incu*Eh.C+m.BA*Ih.B+m.CA*Ih.C-(m.AB+m.AC)*Ih.A
      dRh.A = m.AA*g.A*Ih.A-w.A*Rh.A+m.BA*g.B*Ih.B+m.CA*g.C*Ih.C-(m.AB+m.AC)*Rh.A+m.BA*Rh.B+m.CA*Rh.C
      
      
      dSv.A = bir.A*(Sv.A+Ev.A+Iv.A)-dea.A*Sv.A-b2.A*Ih.A*Sv.A                        
      dEv.A = -dea.A*Ev.A+b2.A*Ih.A*Sv.A-ma*Ev.A 
      dIv.A = -dea.A*Iv.A+ma*Ev.A 
      
      
      
      
      dSh.B = -Sh.B*b1.B*Iv.B+m.BB*w.B*Rh.B-(m.BA+m.BC)*Sh.B+m.AB*Sh.A+m.CB*Sh.C+m.AB*w.A*Rh.A+m.CB*w.C*Rh.C
      dEh.B = m.BB*Sh.B*b1.B*Iv.B-incu*Eh.B+m.AB*Sh.A*b1.A*Iv.A+m.CB*Sh.C*b1.C*Iv.C+m.AB*Eh.A+m.CB*Eh.B-(m.BA+m.BC)*Eh.B
      dIh.B = m.BB*incu*Eh.B-g.B*Ih.B+m.AB*incu*Eh.A+m.CB*incu*Eh.C+m.AB*Ih.A+m.CB*Ih.C-(m.BA+m.BC)*Ih.B
      dRh.B = m.BB*g.B*Ih.B-w.B*Rh.B+m.AB*g.A*Ih.A+m.CB*g.C*Ih.C-(m.BA+m.BC)*Rh.B+m.AB*Rh.A+m.CB*Rh.C
      
      
      dSv.B = bir.B*(Sv.B+Ev.B+Iv.B)-dea.B*Sv.B-b2.B*Ih.B*Sv.B                        
      dEv.B = -dea.B*Ev.B+b2.B*Ih.B*Sv.B-ma*Ev.B 
      dIv.B = -dea.B*Iv.B+ma*Ev.B 
      
      
      
      dSh.C = -Sh.C*b1.C*Iv.C+m.CC*w.C*Rh.C-(m.CA+m.CB)*Sh.C+m.AC*Sh.A+m.BC*Sh.B+m.AC*w.A*Rh.A+m.BC*w.B*Rh.B
      dEh.C = m.CC*Sh.C*b1.C*Iv.C-incu*Eh.C+m.BC*Sh.B*b1.B*Iv.B+m.AC*Sh.A*b1.A*Iv.A+m.BC*Eh.B+m.AC*Eh.A-(m.CA+m.CB)*Eh.C
      dIh.C = m.CC*incu*Eh.C-g.C*Ih.C+m.BC*incu*Eh.B+m.AC*incu*Eh.A+m.AC*Ih.C+m.BC*Ih.B-(m.CA+m.CB)*Ih.C
      dRh.C = m.CC*g.C*Ih.C-w.C*Rh.C+m.BC*g.B*Ih.B+m.AC*g.A*Ih.A-(m.CA+m.CB)*Rh.C+m.BC*Rh.B+m.AC*Rh.A
      
      
      dSv.C = bir.C*(Sv.C+Ev.C+Iv.C)-dea.C*Sv.C-b2.C*Ih.C*Sv.C                        
      dEv.C = -dea.C*Ev.C+b2.C*Ih.C*Sv.C-ma*Ev.C 
      dIv.C = -dea.C*Iv.C+ma*Ev.C 
      
      
      
      list(c(dSh.A, dEh.A, dIh.A, dRh.A, dSh.B, dEh.B, dIh.B, dRh.B, dSh.C, dEh.C, dIh.C, dRh.C, dSv.A , dEv.A , dIv.A , dSv.B , dEv.B , dIv.B , dSv.C , dEv.C , dIv.C ))
    }
  )
}



#' Simulation of a compartmental infectious disease transmission model illustrating metapopulation dynamics
#'
#' @description  This model allows for the simulation of a vector-borne infectious disease with metapopulation dynamics
#' 
#'
#' @param Sh0.* initial number of susceptible hosts in population * 
#' @param Eh0.* initial number of exposed hosts in population *
#' @param Ih0.* initial number of infectious hosts in population *
#' @param Sv0.* initial number of susceptible vectors in population *
#' @param Ev0.* initial number of exposed vectors in population *
#' @param Iv0.* initial number of infected vectors in population *
#'
#' @param tmax maximum simulation time, units of months
#' @param b1.* rate of transmission from infected vector to susceptible host in population *
#' @param b2.* rate of transmission from infected host to susceptible vector in population *
#' @param bir.* the rate of births of vectors in population *
#' @param dea.* the rate of death of vectors in population *
#' @param g.* the rate at which infected hosts recover in population * 
#' @param w.* the rate at which host immunity wanes in population *
#' @param incu the rate at which the parasite enters a sexual reproductive phase
#' @param ma the rate at which the parasite matures to allow transmission to hosts
#'
#'
#' @return This function returns the simulation result as obtained from a call
#'   to the deSolve ode solver
#' @details A compartmental ID model with several states/compartments
#'   is simulated as a set of ordinary differential
#'   equations. The compartments are Sh.*, Eh.*, Ih.*, Rh.*, and Sv.*, Ev.*, Iv.* across * populations.
#'   The function returns the output from the odesolver as a matrix,
#'   with one column per compartment/variable. The first column is time.
#' @section Warning:
#'   This function does not perform any error checking. So if you try to do
#'   something nonsensical (e.g. any negative values or fractions > 1),
#'   the code will likely abort with an error message
#' @examples
#'   # To run the simulation with default parameters just call this function
#'   result <- simulate_metapopulation()
#'   # To choose parameter values other than the standard one, specify them e.g. like such
#'   result <- simulate_metapopulation(Sh0.A = 100, Sv0.A = 1e5,  tmax = 100)
#'   # You should then use the simulation result returned from the function, e.g. like this:
#'   plot(result[,1],result[,2],xlab='Time',ylab='Number Susceptible',type='l')
#' @seealso The UI of the shiny app 'Metapopulation', which is part of this package, contains more details on the model
#' @author Cody Dailey, Andreas Handel
#' @references See the information in the corresponding shiny app for model details
#'            See the documentation for the deSolve package for details on ODE solvers
#' @export


simulate_metapopulation <- function( Sh0.A = 1e2,      Sh0.B = 1e2,      Sh0.C = 1e2,
                                     Eh0.A = 1,        Eh0.B = 0,        Eh0.C = 0,
                                     Ih0.A = 0,        Ih0.B = 0,        Ih0.C = 0,
                                     Rh0.A = 0,        Rh0.B = 0,        Rh0.C = 0,
                                     Sv0.A = 1e2,      Sv0.B = 1e2,      Sv0.C = 1e2,
                                     Ev0.A = 0,        Ev0.B = 0,        Ev0.C = 0,
                                     Iv0.A = 0,        Iv0.B = 0,        Iv0.C = 0,
                                     
                                     tmax = 1000, 
                                     
                                     b1.A = 0.01,      b1.B = 0.01,      b1.C = 0.01,
                                     b2.A = 0.5,       b2.B = 0.5,       b2.C = 0.5,
                                     
                                     bir.A = 1/25,     bir.B = 1/25,     bir.C = 1/25, 
                                     dea.A = 0.001,    dea.B = 0.001,    dea.C = 0.001,
                                     
                                     g.A = 2,          g.B = 2,          g.C = 2, 
                                     w.A = 0.75,       w.B = 0.75,       w.C = 0.75, 
                                     
                                     incu = 3,
                                     ma = 2,
                                     
                                     m.AA = 1, m.AB = 0, m.AC = 0,
                                     m.BB = 1, m.BA = 0, m.BC = 0,
                                     m.CC = 1, m.CA = 0, m.CB = 0 )
{
  ############################################################
  
  
  Y0 = c(Sh.A = Sh0.A, Eh.A = Eh0.A, Ih.A = Ih0.A, Rh.A = Rh0.A,
         Sh.B = Sh0.B, Eh.B = Eh0.B, Ih.B = Ih0.B, Rh.B = Rh0.B,
         Sh.C = Sh0.C, Eh.C = Eh0.C, Ih.C = Ih0.C, Rh.C = Rh0.C,
         Sv.A = Sv0.A, Ev.A = Ev0.A, Iv.A = Iv0.A,
         Sv.B = Sv0.B, Ev.B = Ev0.B, Iv.B = Iv0.B,
         Sv.C = Sv0.C, Ev.C = Ev0.C, Iv.C = Iv0.C);  #combine initial conditions into a vector
  
  
  dt = min(0.1, tmax / 1000); #time step for which to get results back
  
  timevec = seq(0, tmax, dt); #vector of times for which solution is returned (not that internal timestep of the integrator is different)
  
  
  ############################################################
  #vector of parameters which is sent to the ODE function  
  pars=c(b1.A = b1.A, b1.B = b1.B, b1.C = b1.C, 
         b2.A = b2.A, b2.B = b2.B, b2.C = b2.C, 
         bir.A = bir.A, bir.B = bir.B, bir.C = bir.C, 
         dea.A = dea.A, dea.B = dea.B, dea.C = dea.C, 
         g.A = g.A, g.B = g.B, g.C = g.C, 
         w.A = w.A, w.B = w.B, w.C = w.C, 
         incu = incu,
         ma = ma,
         m.AA = m.AA, m.BB = m.BB, m.CC = m.CC, 
         m.AB = m.AB, m.AC = m.AC, 
         m.BA = m.BA, m.BC = m.BC, 
         m.CA = m.CA, m.CB = m.CB); 
  
  #this line runs the simulation, i.e. integrates the differential equations describing the infection process
  #the result is saved in the odeoutput matrix, with the 1st column the time, the 2nd, 3rd, 4th column the variables S, I, R
  #This odeoutput matrix will be re-created every time you run the code, so any previous results will be overwritten
  odeoutput = deSolve::lsoda(Y0, timevec, func = METAPOP.eq, parms=pars, atol=1e-12, rtol=1e-12);
  
  return (odeoutput)
}