
METAPOP.eq2 <- function(t, y, parms)
{
  with(
    as.list(c(y,parms)),
    {
      #the ordinary differential equations
      
      dSh.An = - Sh.An * Iv.A * b1.An   +   Rh.An *  w.A   -   em.A * Sh.An                    +   (Sh.Bf + Sh.Cf) * ret
      dIh.An =   Sh.An * Iv.A * b1.An   -   Ih.An *  g.A   -   em.A * Ih.An * ill              +   (Ih.Bf + Ih.Cf) * ret * (1 / ill)
      dRh.An =   Ih.An *  g.A           -   Rh.An *  w.A   -   em.A * Rh.An                    +   (Rh.Bf + Rh.Cf) * ret
      
      dSh.Af = - Sh.Af * Iv.A * b1.Af   +   Rh.Af *  w.A   +   (Sh.Bn + Sh.Cn) * imm.A         -   Sh.Af * ret
      dIh.Af =   Sh.Af * Iv.A * b1.Af   -   Ih.Af *  g.A   +   (Ih.Bn + Ih.Cn) * imm.A * ill   -   Ih.Af * ret * (1 / ill)
      dRh.Af =   Ih.Af *  g.A           -   Rh.Af *  w.A   +   (Rh.Bn + Rh.Cn) * imm.A         -   Rh.Af * ret
      
      
      
      dSv.A = - Sv.A * b2.A * (Ih.An + Ih.Af)   -   dr.A * Sv.A   +   br.A                      
      dIv.A =   Sv.A * b2.A * (Ih.An + Ih.Af)   -   Iv.A *  dr.A
      
      
      
      
      
      dSh.Bn = - Sh.Bn * Iv.B * b1.Bn   +   Rh.Bn *  w.B   -   em.B * Sh.Bn                    +   (Sh.Af + Sh.Cf) * ret
      dIh.Bn =   Sh.Bn * Iv.B * b1.Bn   -   Ih.Bn *  g.B   -   em.B * Ih.Bn * ill              +   (Ih.Af + Ih.Cf) * ret * (1 / ill)
      dRh.Bn =   Ih.Bn *  g.B           -   Rh.Bn *  w.B   -   em.B * Rh.Bn                    +   (Rh.Af + Rh.Cf) * ret
      
      dSh.Bf = - Sh.Bf * Iv.B * b1.Bf   +   Rh.Bf *  w.B   +   (Sh.An + Sh.Cn) * imm.B         -   Sh.Bf * ret
      dIh.Bf =   Sh.Bf * Iv.B * b1.Bf   -   Ih.Bf *  g.B   +   (Ih.An + Ih.Cn) * imm.B * ill   -   Ih.Bf * ret * (1 / ill)
      dRh.Bf =   Ih.Bf *  g.B           -   Rh.Bf *  w.B   +   (Rh.An + Rh.Cn) * imm.B         -   Rh.Bf * ret
      
      
      
      dSv.B = - Sv.B * b2.B * (Ih.Bn + Ih.Bf)   -   dr.B * Sv.B   +   br.B                      
      dIv.B =   Sv.B * b2.B * (Ih.Bn + Ih.Bf)   -   Iv.B *  dr.B
      
      
      
      
      
      dSh.Cn = - Sh.Cn * Iv.C * b1.Cn   +   Rh.Cn *  w.C   -   em.C * Sh.Cn                    +   (Sh.Af + Sh.Bf) * ret
      dIh.Cn =   Sh.Cn * Iv.C * b1.Cn   -   Ih.Cn *  g.C   -   em.C * Ih.Cn * ill              +   (Ih.Af + Ih.Bf) * ret * (1 / ill)
      dRh.Cn =   Ih.Cn *  g.C           -   Rh.Cn *  w.C   -   em.C * Rh.Cn                    +   (Rh.Af + Rh.Bf) * ret
      
      dSh.Cf = - Sh.Cf * Iv.C * b1.Cf   +   Rh.Cf *  w.C   +   (Sh.An + Sh.Bn) * imm.C         -   Sh.Cf * ret
      dIh.Cf =   Sh.Cf * Iv.C * b1.Cf   -   Ih.Cf *  g.C   +   (Ih.An + Ih.Bn) * imm.C * ill   -   Ih.Cf * ret * (1 / ill)
      dRh.Cf =   Ih.Cf *  g.C           -   Rh.Cf *  w.C   +   (Rh.An + Rh.Bn) * imm.C         -   Rh.Cf * ret
      
      
      
      dSv.C = - Sv.C * b2.C * (Ih.Cn + Ih.Cf)   -   dr.C * Sv.C   +   br.C                      
      dIv.C =   Sv.C * b2.C * (Ih.Cn + Ih.Cf)   -   Iv.C *  dr.C
      
      
      
    
        
        
        
        
        
      list(c(dSh.An, dIh.An, dRh.An,   dSh.Af, dIh.Af, dRh.Af,   dSv.A, dIv.A,
             dSh.Bn, dIh.Bn, dRh.Bn,   dSh.Bf, dIh.Bf, dRh.Bf,   dSv.B, dIv.B,
             dSh.Cn, dIh.Cn, dRh.Cn,   dSh.Cf, dIh.Cf, dRh.Cf,   dSv.C, dIv.C))
    }
  )
}



#' Simulation of a compartmental infectious disease transmission model illustrating metapopulation dynamics
#'
#' @description  This model allows for the simulation of a vector-borne infectious disease with metapopulation dynamics
#' 
#'
#' @param Sh0.*n initial number of susceptible native hosts in population * 
#' @param Ih0.*n initial number of infectious native hosts in population *
#' @param Rh0.*n initial number of recovered native hosts in population *
#' 
#' @param Sh0.*f initial number of susceptible foreign hosts in population * 
#' @param Ih0.*f initial number of infectious foreign hosts in population *
#' @param Rh0.*f initial number of recovered foreign hosts in population *
#' 
#' 
#' @param Sv0.* initial number of susceptible vectors in population *
#' @param Iv0.* initial number of infected vectors in population *
#'
#'
#' @param tmax maximum simulation time, units of months
#' 
#' 
#' @param b1.*n rate of transmission from infected vector to susceptible native host in population *
#' @param b1.*f rate of transmission from infected vector to susceptible foreign host in population *
#' @param b2.* rate of transmission from infected host to susceptible vector in population *
#' 
#' @param br.* the rate of births of vectors in population *
#' @param dr.* the rate of death of vectors in population *
#' 
#' @param g.* the rate at which infected hosts recover in population * 
#' @param w.* the rate at which host immunity wanes in population *
#' 
#' @param em.* the rate of emigration (egress) of native hosts from population *
#' @param imm.* the rate of immigration (entry) of foreign hosts to population *
#'  
#' @param ill a factor adjusting movement of infected hosts
#' @param ret the rate of return, foreign hosts return to native population
#'
#'
#' @return This function returns the simulation result as obtained from a call
#'   to the deSolve ode solver
#' @details A compartmental ID model with several states/compartments
#'   is simulated as a set of ordinary differential
#'   equations. The compartments are Sh.*, Eh.*, Ih.*, Rh.*, and Sv.*, Ev.*, Iv.* across * populations.
#'   The function returns the output from the odesolver as a matrix,
#'   with one column per compartment/variable. The first column is time.
#' @section Warning:
#'   This function does not perform any error checking. So if you try to do
#'   something nonsensical (e.g. any negative values or fractions > 1),
#'   the code will likely abort with an error message
#' @examples
#'   # To run the simulation with default parameters just call this function
#'   result <- simulate_metapopulation()
#'   # To choose parameter values other than the standard one, specify them e.g. like such
#'   result <- simulate_metapopulation(Sh0.A = 100, Sv0.A = 1e5,  tmax = 100)
#'   # You should then use the simulation result returned from the function, e.g. like this:
#'   plot(result[,1],result[,2],xlab='Time',ylab='Number Susceptible',type='l')
#' @seealso The UI of the shiny app 'Metapopulation', which is part of this package, contains more details on the model
#' @author Cody Dailey, Andreas Handel
#' @references See the information in the corresponding shiny app for model details
#'            See the documentation for the deSolve package for details on ODE solvers
#' @export


simulate_metapopulation_foreign <- function( 
                                     Sh0.An = 1e2,      Sh0.Bn = 1e2,      Sh0.Cn = 1e2,
                                     Ih0.An = 0,        Ih0.Bn = 0,        Ih0.Cn = 0,
                                     Rh0.An = 0,        Rh0.Bn = 0,        Rh0.Cn = 0,
                                     
                                     Sh0.Af = 1e2,      Sh0.Bf = 1e2,      Sh0.Cf = 1e2,
                                     Ih0.Af = 0,        Ih0.Bf = 0,        Ih0.Cf = 0,
                                     Rh0.Af = 0,        Rh0.Bf = 0,        Rh0.Cf = 0,
                                     
                                     
                                     Sv0.A = 1e2,       Sv0.B = 1e2,       Sv0.C = 1e2,
                                     Iv0.A = 0,         Iv0.B = 0,         Iv0.C = 0,
                                     
                                     
                                     tmax = 1000, 
                                     
                                     
                                     b1.An = 0.01,      b1.Bn = 0.01,      b1.Cn = 0.01,
                                     b1.Af = 0.01,      b1.Bf = 0.01,      b1.Cf = 0.01,
                                     b2.A = 0.5,        b2.B = 0.5,        b2.C = 0.5,
                                     
                                     br.A = 1/25,       br.B = 1/25,       br.C = 1/25, 
                                     dr.A = 0.001,      dr.B = 0.001,      dr.C = 0.001,
                                     
                                     g.A = 2,           g.B = 2,           g.C = 2, 
                                     w.A = 0,        w.B = 0,        w.C = 0, 
                                     
                                     em.A = 0 ,         em.B = 0,          em.C = 0,
                                     imm.A = 0 ,        imm.B = 0,         imm.C = 0,
                                     
                                     ill = 1, 
                                     ret = 0
                                     )
{
  ############################################################
  
  
  Y0 = c(Sh.An = Sh0.An, Ih.An = Ih0.An, Rh.An = Rh0.An,
         Sh.Af = Sh0.Af, Ih.Af = Ih0.Af, Rh.Af = Rh0.Af,
         Sv.A = Sv0.A, Iv.A = Iv0.A,
         Sh.Bn = Sh0.Bn, Ih.Bn = Ih0.Bn, Rh.Bn = Rh0.Bn,
         Sh.Bf = Sh0.Bf, Ih.Bf = Ih0.Bf, Rh.Bf = Rh0.Bf,
         Sv.B = Sv0.B, Iv.B = Iv0.B,
         Sh.Cn = Sh0.Cn, Ih.Cn = Ih0.Cn, Rh.Cn = Rh0.Cn,
         Sh.Cf = Sh0.Cf, Ih.Cf = Ih0.Cf, Rh.Cf = Rh0.Cf,
         Sv.C = Sv0.C, Iv.C = Iv0.C);  #combine initial conditions into a vector
  
  
  dt = min(0.1, tmax / 1000); #time step for which to get results back
  
  timevec = seq(0, tmax, dt); #vector of times for which solution is returned (not that internal timestep of the integrator is different)
  
  
  ############################################################
  #vector of parameters which is sent to the ODE function  
  pars=c(b1.An = b1.An, b1.Bn = b1.Bn, b1.Cn = b1.Cn,
         b1.Af = b1.Af, b1.Bf = b1.Bf, b1.Cf = b1.Cf, 
         b2.A = b2.A, b2.B = b2.B, b2.C = b2.C,
         
         br.A = br.A, br.B = br.B, br.C = br.C, 
         dr.A = dr.A, dr.B = dr.B, dr.C = dr.C,
         
         g.A = g.A, g.B = g.B, g.C = g.C, 
         w.A = w.A, w.B = w.B, w.C = w.C, 
         
         ill = ill,
         ret = ret, 
         
         em.A = em.A, em.B = em.B, em.C = em.C,
         imm.A = imm.A, imm.B = imm.B, imm.C = imm.C
         ); 
  
  #this line runs the simulation, i.e. integrates the differential equations describing the infection process
  #the result is saved in the odeoutput matrix, with the 1st column the time, the 2nd, 3rd, 4th column the variables S, I, R
  #This odeoutput matrix will be re-created every time you run the code, so any previous results will be overwritten
  odeoutput = deSolve::lsoda(Y0, timevec, func = METAPOP.eq2, parms=pars, atol=1e-12, rtol=1e-12);
  
  return (odeoutput)
}
